repo_root=fileparts(fileparts(mfilename('fullpath')));
cd(repo_root); addpath(fullfile(repo_root,'mlab'));
out=fullfile(repo_root,'output','experimental_statistics');
if ~exist(out,'dir'), mkdir(out); end
diary(fullfile(out,'matlab_run.log'));
datasets=run_parameter_error_win_analysis(struct('fig_dir',out,'show_figures',false));
for k=1:numel(datasets)
    ds=datasets(k);
    summary=struct();
    keys={'method_names','final_errors','final_param_estimates','statuses', ...
        'point_estimate_valid','shared_reference_methods'};
    for j=1:numel(keys)
        if isfield(ds.mc_summary,keys{j}), summary.(keys{j})=ds.mc_summary.(keys{j}); end
    end
    snapshot=struct('source_file',ds.file,'experiment',ds.experiment,'mc_summary',summary, ...
        'win_metadata',ds.win_metadata,'normality_metadata',ds.normality_metadata);
    stem=sprintf('%s_%s_%s',lower(string(ds.experiment.name)), ...
        lower(string(ds.experiment.mode)),lower(string(ds.parametrization)));
    fid=fopen(fullfile(out,['samples_' char(stem) '.json']),'w');
    assert(fid~=-1); fprintf(fid,'%s',jsonencode(snapshot)); fclose(fid);
end
diary off;
disp('Fresh statistical figures, tables, and normalized samples exported.');
